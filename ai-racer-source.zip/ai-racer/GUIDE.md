# Live population training update

## Install into your existing project

This ZIP is an update, not the full game. Copy its Python files into the same
folder as your existing car.py, track.py, network.py, sensors.py, controller.py,
camera.py, race.py and settings.py. Back up evaluation.py and train.py first;
these are the only existing files replaced. Keep your working main.py and its
champion-loading code.

New files: agent.py, evolution.py, live_train.py, test_live_training.py.
Replacements: evaluation.py, train.py.

Run:

```powershell
py live_train.py
```

It uses your existing pygame-ce installation. Each run begins with a fresh random
population (seed 42), not your saved champion. Same seed and settings mean the
same experiment. Allow at least 8 simulated seconds for stationary cars to time
out. Generations last at most 30 simulated seconds, plus a 1.5-second viewing pause.

## Controls

- Space: pause/resume.
- 1 / 2 / 3: target playback speeds of 1x / 2x / 4x.
- F: switch whole-track overview / follow the strongest active car.
- S: show the followed leader's rays.
- Enter: advance immediately after a generation has finished.
- Esc or window close: exit.

Thirty cars share the same starting position and track. Their colours vary by
population slot, not permanent family identity. They overlap initially and never
collide with one another. Stopped unsuccessful attempts are drawn at low opacity;
completed cars stay solid. The strongest active car has a gold ring; after all
attempts finish, the ring marks the generation winner. The active leader can have
a lower score than a car that already crashed. Yellow checkpoints show that
leader's next target. Cars with other targets still use their own Race state.

The dashboard displays generation, active count, finished laps this generation,
best score so far, leader status and the best lap from completed generations.
After generation 20, the final scene remains visible until you exit.

## How the files fit together

Agent bundles one independent controller, Car, Race, Sensors, score, counters and
status. Its step() advances only one fixed simulation tick. Once ended, step()
does nothing: cars cannot reset and earn another attempt in the same generation.

```python
for agent in session.agents:
    agent.step(SIMULATION_DT, track)
```

This is sequential execution of one tick per car, not CPU parallelism. It appears
simultaneous because all cars advance before drawing the next frame.

The old evaluate() loop now becomes:

```python
agent = Agent(network, track)
while agent.active:
    agent.step(SIMULATION_DT, track)
return agent.fitness, agent.status
```

TrainingSession waits until every attempt ends, ranks fitness, saves the result,
then breeds the next population. The population rules are shared in evolution.py:
2 unchanged elites, 24 mutated copies drawn from the top 6, 4 new random networks.
Generations and population settings now live in evolution.py, not train.py.
Keep these counts consistent if changing population size.

Agent.draw() fades a COPY of the car image. It never changes the physics image or
mask. Track and sensor drawing do not award fitness or otherwise alter the
simulation. The viewer uses the existing Camera for follow mode and scales a
whole-world render for overview mode.

## Saved results and champion playback

Each run creates its own training_runs/<timestamp>/ directory next to the scripts.
The directory path is printed at startup. A better champion is saved after each
completed generation, in the same JSON format your main.py loader uses.
The visual trainer also writes history.json with generation scores and outcomes.
Your existing root champion.json is not overwritten.

To watch a new champion in your normal game: keep a backup of the old root
champion.json, copy the desired run's champion.json beside main.py, then restart
main.py and press Tab. A live run is a new experiment; it does not resume from
champion.json. Closing mid-generation keeps earlier saved generations, but the
current unfinished generation is not saved. History and champion files are not
full-population resume checkpoints.

## Scope and current limitations

The physics, neural network, sensors, checkpoint scoring, 30-second attempt limit,
8-second no-progress rule and 1-point improvement threshold follow your supplied
code. All finishers still score 4000; faster lap times are displayed but do not yet
receive extra fitness. Straight-line distance-to-checkpoint scoring is still an
approximation. Future improvement: progress measured along the course.

Speed controls run MORE fixed steps, never larger dt values. If rendering and
sensors are too expensive, target wall-clock speed may not be achieved. Catch-up
work is bounded for responsiveness, while each simulated attempt still gets its
full fixed-step budget. This update does not promise a lap in 20 generations.

The standalone fast trainer runs with `py train.py` and shares Agent/evolution
rules. It also saves to a separate timestamped directory. This changes where
train.py saves its champion compared with the earlier script.

## Checks

```powershell
py -m unittest test_live_training -v
```

Five tests cover visual/fast result parity, independent coloured agents, terminal
states, frozen crashes, mask-preserving fades, elitism, generation transitions,
saves and drawing. A separate startup smoke check is available:

```powershell
py live_train.py --smoke-frames 3
```

Validated with pygame-ce 2.5.8 in an off-screen display. Two full 30-car generations
were exercised and the rendered overview inspected. Old/new evaluator results
also matched for three seeded controllers. Test your controls locally; automated
checks do not establish smooth frame rates on your laptop. This update's tests
are separate from older test_game.py, whose hard-coded coordinates may be stale.
