# AI Racer

A local Python / Pygame CE racing experiment with manual driving, a saved neural-network controller and evolutionary training. It is an ongoing desktop learning project developed with AI assistance, not a browser app or production game.

## Run

Tested with Python 3.12.3 and pygame-ce 2.5.8. Install Python 3.12 and open a terminal in this folder. A virtual environment is recommended.

```bash
python -m venv .venv
# macOS/Linux:
source .venv/bin/activate
# Windows PowerShell instead:
# .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python main.py
```

On Windows, `py` can replace `python`. The only declared external dependency is `pygame-ce>=2.5,<3`. The normal desktop run needs a graphical display; the special dummy SDL driver below is for automated checks, not interactive play.

## Controls

W/Up accelerates, S/Down brakes, A/Left and D/Right steer. R resets the attempt. Tab toggles manual driving and the supplied saved-champion AI, resetting the attempt. T prints the current sensor inputs and AI decision; closing the window exits. `main.py` loads `champion.json` from this folder. The archive includes one saved champion; no external API/model service is used.

## Watch training

```bash
python live_train.py
```

Space pauses. 1/2/3 choose target 1x/2x/4x speed. F changes overview/follow-leader camera, S toggles leader sensor rays, Enter advances a finished generation and Esc exits. See `GUIDE.md` for more detail. `python train.py` evaluates without the live viewer.

Training writes new `training_runs/<timestamp>/champion.json` and `history.json` files. These are local output files, not a database. To use a new trained controller in the ordinary game, preserve the existing champion if wanted and copy the desired run's `champion.json` into this folder. The viewer does not automatically replace the root champion.

## What is implemented

The display is 1000x700 and the track is a larger 2000x1400 world viewed through `Camera`. Simulation uses fixed 1/60-second steps, not a variable-timestep physics update. Cars have velocity, grip, mask collisions and directional checkpoints/lap timing. Seven obstacle rays plus four motion/target values feed an 11-input, 8-hidden, 3-output tanh neural controller. Controller weights remain fixed during each attempt; selection and mutation happen between generations.

The live trainer evaluates a population of 30 networks, shows drivers and status, preserves elite controllers and writes training metrics. Rendering targets 60 FPS but requested playback speed and smoothness are not guaranteed on every machine. This prototype does not establish generalisation to new tracks or robust lap-completion performance.

## Tests and finite smoke check

```bash
python -m unittest -v test_game test_live_training
python live_train.py --smoke-frames 5
```

For headless macOS/Linux/CI checks:

```bash
SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy \
  python -m unittest -v test_game test_live_training
```

All ten supplied tests passed in the local Python 3.12.3 / Pygame CE 2.5.8 headless check on 25 October 2026. The tests cover physics/motion, collisions/checkpoints, independent cars, rendering and core training transitions. They are not a proof of laptop performance, unseen-track success or a flawless AI driver.

## Source archive

All original Python source, tests, requirements, GUIDE and root champion are unchanged. This README has been reconciled with the current source; the uploaded README had older variable-timestep and no-camera descriptions. Cached bytecode and redundant timestamped training-run copies are omitted. The original submitted ZIP is preserved separately. No public GitHub repository or browser deployment is claimed by this package.
