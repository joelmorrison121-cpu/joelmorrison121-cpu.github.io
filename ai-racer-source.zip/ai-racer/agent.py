"""One controller's attempt. Rendering does not change its fitness or physics."""
import pygame
from car import Car
from race import Race
from sensors import Sensors
from controller import get_observation, choose_action
from settings import SIMULATION_DT


class Agent:
    def __init__(self, network, track, number=1, colour=(255, 165, 0)):
        self.network = network
        self.number = number
        self.colour = colour
        self.car = Car(track.start_position, track.start_angle)
        # Recolour only the body; preserve the original image's transparency.
        pygame.draw.rect(self.car.base_image, colour, (0, 0, 44, 24), border_radius=5)
        pygame.draw.rect(self.car.base_image, 'lightblue', (28, 4, 9, 16))
        self.car.refresh_shape()
        self.race = Race()
        self.sensors = Sensors()
        self.status = 'driving'
        self.fitness = 0.0
        self.steps = 0
        self.last_improvement_step = 0
        self.max_steps = round(30 / SIMULATION_DT)
        self.patience_steps = round(8 / SIMULATION_DT)
        self.starting_distance = self.distance_to_target(track)

    @property
    def active(self):
        return self.status == 'driving'

    def distance_to_target(self, track):
        centre = pygame.Vector2(track.checkpoints[self.race.next_checkpoint].rect.center)
        return max(self.car.position.distance_to(centre), 1.0)

    def step(self, dt, track):
        if not self.active:
            return
        # All callers use the same fixed timestep.
        if abs(dt - SIMULATION_DT) > 1e-12:
            raise ValueError('Agent.step requires SIMULATION_DT')
        step_index = self.steps
        self.steps += 1
        self.sensors.update(self.car, track)
        observation = get_observation(self.car, track, self.race, self.sensors)
        actions = choose_action(self.network, observation)
        self.car.update(dt, *actions)
        self.race.advance_timer(dt, self.car.speed)

        if track.collides(self.car):
            self.status = 'crashed'
            return

        old_checkpoint = self.race.next_checkpoint
        self.race.check_progress(track, self.car.previous_position, self.car.position)
        if self.race.laps_completed:
            self.fitness = len(track.checkpoints) * 1000.0
            self.status = 'completed lap'
            return

        target = pygame.Vector2(track.checkpoints[self.race.next_checkpoint].rect.center)
        if self.race.next_checkpoint != old_checkpoint:
            self.starting_distance = self.distance_to_target(track)
        distance = self.car.position.distance_to(target)
        progress = max(0.0, min(1 - distance / self.starting_distance, 0.99))
        score = self.race.next_checkpoint * 1000 + progress * 1000
        if score > self.fitness + 1.0:
            self.last_improvement_step = step_index
        self.fitness = max(self.fitness, score)
        if step_index - self.last_improvement_step >= self.patience_steps:
            self.status = 'no progress'
        elif self.steps >= self.max_steps:
            self.status = 'time limit'

    def draw(self, screen, camera, leader=False, font=None):
        rect = camera.apply_rect(self.car.rect)
        image = self.car.image
        if not self.active and self.status != 'completed lap':
            # Fade a COPY. Changing the collision image's alpha would corrupt masks.
            image = image.copy()
            image.set_alpha(65)
        screen.blit(image, rect)
        if leader:
            pygame.draw.circle(screen, (255, 230, 80), rect.center, 34, 3)
            if font:
                label = font.render(f'LEADER #{self.number}', True, (255, 230, 80))
                screen.blit(label, (rect.centerx - label.get_width() // 2, rect.top - 27))
