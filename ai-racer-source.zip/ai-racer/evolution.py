"""Population creation, mutation and saving shared by both trainers."""
import copy
import json
import random
from datetime import datetime, timezone
from pathlib import Path
from network import NeuralNetwork

POPULATION_SIZE = 30
GENERATIONS = 20
ELITE_COUNT = 2
PARENT_COUNT = 6
NEW_NETWORK_COUNT = 4
MUTATION_RATE = 0.15
MUTATION_STRENGTH = 0.2


def mutate(parent, rng):
    child = copy.deepcopy(parent)
    for matrix in (child.hidden_weights, child.output_weights):
        for row in matrix:
            for i in range(len(row)):
                if rng.random() < MUTATION_RATE:
                    row[i] += rng.gauss(0, MUTATION_STRENGTH)
    for biases in (child.hidden_biases, child.output_biases):
        for i in range(len(biases)):
            if rng.random() < MUTATION_RATE:
                biases[i] += rng.gauss(0, MUTATION_STRENGTH)
    return child


def new_population(rng):
    return [NeuralNetwork(seed=rng.randrange(1_000_000_000))
            for _ in range(POPULATION_SIZE)]


def breed(ranked_networks, rng):
    """Input must already be sorted from highest fitness to lowest."""
    children = [copy.deepcopy(n) for n in ranked_networks[:ELITE_COUNT]]
    parents = ranked_networks[:PARENT_COUNT]
    while len(children) < POPULATION_SIZE - NEW_NETWORK_COUNT:
        children.append(mutate(rng.choice(parents), rng))
    children.extend(NeuralNetwork(seed=rng.randrange(1_000_000_000))
                    for _ in range(NEW_NETWORK_COUNT))
    return children


def create_run_directory():
    # Each run has its own files; existing champion.json is never overwritten.
    stamp = datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')
    path = Path(__file__).resolve().parent / 'training_runs' / stamp
    path.mkdir(parents=True)
    return path


def save_champion(network, fitness, generation, path):
    data = dict(generation=generation, fitness=fitness,
                hidden_weights=network.hidden_weights, hidden_biases=network.hidden_biases,
                output_weights=network.output_weights, output_biases=network.output_biases)
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(data, indent=2), encoding='utf-8')
    temporary.replace(path)
