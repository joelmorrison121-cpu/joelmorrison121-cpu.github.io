"""Evaluate one Agent without drawing. Same rules as live training."""
import pygame
from agent import Agent
from network import NeuralNetwork
from track import Track
from settings import SIMULATION_DT


def evaluate(network, track=None):
    if track is None:
        track = Track()
    agent = Agent(network, track)
    while agent.active:
        agent.step(SIMULATION_DT, track)
    return agent.fitness, agent.status


if __name__ == '__main__':
    pygame.init()
    try:
        fitness, reason = evaluate(NeuralNetwork(seed=42))
        print(f'Fitness: {fitness:.1f}\nAttempt ended: {reason}')
    finally:
        pygame.quit()
