"""Fast training: evaluate sequentially, using the live trainer's Agent rules."""
import random
import pygame
from evaluation import evaluate
from track import Track
from evolution import (GENERATIONS, new_population, breed, create_run_directory,
                       save_champion)


def train():
    rng = random.Random(42)
    track = Track()
    population = new_population(rng)
    output = create_run_directory()
    print(f'Saving this run in: {output}', flush=True)
    best_ever = -1.0
    for generation in range(1, GENERATIONS + 1):
        results = []
        for network in population:
            fitness, reason = evaluate(network, track)
            results.append((fitness, network, reason))
        results.sort(key=lambda result: result[0], reverse=True)
        best_fitness, champion, reason = results[0]
        average = sum(result[0] for result in results) / len(results)
        print(f'Generation {generation:02d} | Best: {best_fitness:.1f} | '
              f'Average: {average:.1f} | {reason}', flush=True)
        if best_fitness > best_ever:
            best_ever = best_fitness
            save_champion(champion, best_fitness, generation, output / 'champion.json')
        if generation < GENERATIONS:
            population = breed([result[1] for result in results], rng)
    print(f'Champion: {output / "champion.json"}')


if __name__ == '__main__':
    pygame.init()
    try:
        train()
    finally:
        pygame.quit()
