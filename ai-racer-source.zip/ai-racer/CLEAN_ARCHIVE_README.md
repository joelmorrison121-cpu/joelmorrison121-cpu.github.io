# Clean source archive preparation

Prepared from Joel's uploaded `ai-racer.zip` (original SHA256 `6cd29ad9da14d900a1cd72ae79e6329b84ab6678b1e6f454f48c7fd7c470931a`). The original uploaded ZIP is untouched. All 17 Python files, root champion.json, requirements.txt and GUIDE.md are byte-for-byte unchanged. The README is updated for the actual fixed-step/camera implementation and run commands.

This copy omits cached bytecode and duplicate timestamped training runs. Ten original tests passed locally on Python 3.12.3 with pygame-ce 2.5.8. A finite capture ran the original main loop with Tab selecting its existing saved-champion AI mode; source was not rewritten. Demo and tests are local desktop evidence, not a browser port, public repository or generalisation/performance guarantee.
