"""Entry point: input, simulation order and presentation."""
import json
from pathlib import Path

import pygame
from car import Car
from track import Track
from race import Race
from hud import HUD
from camera import Camera
from sensors import Sensors
from controller import get_observation, choose_action
from network import NeuralNetwork
from settings import (
    WIDTH,
    HEIGHT,
    FPS,
    SIMULATION_DT,
    MAX_FRAME_TIME,
)


def read_controls(keys):
    accelerating = keys[pygame.K_w] or keys[pygame.K_UP]
    braking = keys[pygame.K_s] or keys[pygame.K_DOWN]
    steering = (int(keys[pygame.K_a] or keys[pygame.K_LEFT])
                - int(keys[pygame.K_d] or keys[pygame.K_RIGHT]))
    return accelerating, braking, steering


def reset_attempt(car, race):
    car.reset()
    race.reset_attempt()


def update_game(car, track, race, dt, accelerating, braking, steering):
    car.update(dt, accelerating, braking, steering)
    race.advance_timer(dt, car.speed)
    if track.collides(car):
        reset_attempt(car, race)
    else:
        race.check_progress(track, car.previous_position, car.position)


def load_champion():
    path = Path(__file__).with_name("champion.json")

    if not path.exists():
        raise FileNotFoundError(
            "champion.json was not found. Run py train.py first."
        )

    data = json.loads(path.read_text(encoding="utf-8"))

    network = NeuralNetwork(seed=42)

    # Replace the random parameters with the trained parameters.
    network.hidden_weights = data["hidden_weights"]
    network.hidden_biases = data["hidden_biases"]
    network.output_weights = data["output_weights"]
    network.output_biases = data["output_biases"]

    print(
        f"Loaded champion from generation {data['generation']} "
        f"with fitness {data['fitness']:.1f}"
    )

    return network


def main():
    pygame.init()
    try:
        screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("My First AI Racer")
        clock = pygame.time.Clock()
        track = Track()
        car = Car(track.start_position, track.start_angle)
        race = Race()
        hud = HUD()
        camera = Camera(screen.get_size(), track.world_size)
        sensors = Sensors()
        network = load_champion()
        ai_enabled = False
        accumulator = 0.0
        running = True
        while running:
            frame_time = min(clock.tick(FPS) / 1000, MAX_FRAME_TIME)
            accumulator += frame_time

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_r:
                    reset_attempt(car, race)
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_t:
                    sensors.update(car, track)

                    observation = get_observation(
                        car, track, race, sensors
                    )

                    accelerating, braking, steering = choose_action(
                        network, observation
                    )

                    print("Inputs:", [round(x, 2) for x in observation])
                    print(
                        f"AI decision: accelerate={accelerating}, "
                        f"brake={braking}, steering={steering:.2f}"
                    )
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_TAB:
                    ai_enabled = not ai_enabled

                    # Start each mode from a fresh attempt.
                    reset_attempt(car, race)

                    mode = "AI" if ai_enabled else "Manual"
                    print(f"Control mode: {mode}")
            if not running:
                break

            keys = pygame.key.get_pressed()

            while accumulator >= SIMULATION_DT:
                if ai_enabled:
                    sensors.update(car, track)

                    observation = get_observation(
                        car, track, race, sensors
                    )

                    accelerating, braking, steering = choose_action(
                        network, observation
                    )
                else:
                    accelerating, braking, steering = read_controls(keys)

                update_game(
                    car,
                    track,
                    race,
                    SIMULATION_DT,
                    accelerating,
                    braking,
                    steering,
                )

                accumulator -= SIMULATION_DT

            # Draw once after processing the pending simulation steps.
            sensors.update(car, track)
            camera.update(car.position)

            mode = "AI" if ai_enabled else "Manual"
            pygame.display.set_caption(
                f"My First AI Racer | {mode} | Tab: switch mode"
            )

            track.draw(screen, race.next_checkpoint, camera)
            sensors.draw(screen, camera, car)
            car.draw(screen, camera)
            hud.draw(screen, car, race, len(track.checkpoints))

            pygame.display.flip()
    finally:
        pygame.quit()


if __name__ == "__main__":
    main()