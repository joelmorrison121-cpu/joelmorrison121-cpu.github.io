"""World geometry, collision map and directional checkpoint geometry."""
import pygame
from settings import GRASS_COLOUR, ROAD_COLOUR


class Checkpoint:
    def __init__(self, rect, forward):
        self.rect = pygame.Rect(rect)
        self.forward = pygame.Vector2(forward)

    def crossed(self, previous, current):
        centre = pygame.Vector2(self.rect.center)
        previous_side = (previous - centre).dot(self.forward)
        current_side = (current - centre).dot(self.forward)
        if not (previous_side < 0 <= current_side):
            return False
        fraction = -previous_side / (current_side - previous_side)
        crossing = previous.lerp(current, fraction)
        if self.forward.x != 0:
            return self.rect.top <= crossing.y < self.rect.bottom
        return self.rect.left <= crossing.x < self.rect.right

    def draw(self, screen, active, camera):
        colour = (255, 220, 70) if active else (110, 110, 120)

        if self.forward.x != 0:
            start = (self.rect.centerx, self.rect.top)
            end = (self.rect.centerx, self.rect.bottom)
        else:
            start = (self.rect.left, self.rect.centery)
            end = (self.rect.right, self.rect.centery)

        pygame.draw.line(
            screen,
            colour,
            camera.apply_point(start),
            camera.apply_point(end),
            3,
        )


class Track:
    def __init__(self):
        # The whole game world, independent of the visible window.
        self.world_size = (2000, 1400)
        self.bounds = pygame.Rect((0, 0), self.world_size)

        # Track geometry: x, y, width, height.
        self.outer = pygame.Rect(100, 100, 1800, 1200)
        self.inner = pygame.Rect(400, 400, 1200, 600)

        # Start on the top straight, facing right.
        self.start_position = (500, 250)
        self.start_angle = 0

        # Clockwise route: right → bottom → left → top.
        self.checkpoints = [
            Checkpoint((1600, 680, 300, 40), (0, 1)),
            Checkpoint((980, 1000, 40, 300), (-1, 0)),
            Checkpoint((100, 680, 300, 40), (0, -1)),
            Checkpoint((480, 100, 40, 300), (1, 0)),
        ]

        self.obstacle_mask = self.build_collision_mask()

    def build_collision_mask(self):
        surface = pygame.Surface(self.world_size, pygame.SRCALPHA)
        surface.fill((255, 255, 255, 255))
        pygame.draw.rect(surface, (0, 0, 0, 0), self.outer)
        pygame.draw.rect(surface, (255, 255, 255, 255), self.inner)
        return pygame.mask.from_surface(surface)

    def collides(self, car):
        outside_world = not self.bounds.contains(car.rect)
        overlap = self.obstacle_mask.overlap(car.mask, car.rect.topleft)
        return outside_world or overlap is not None

    def draw(self, screen, next_checkpoint, camera):
        screen.fill(GRASS_COLOUR)

        pygame.draw.rect(
            screen, ROAD_COLOUR, camera.apply_rect(self.outer)
        )
        pygame.draw.rect(
            screen, GRASS_COLOUR, camera.apply_rect(self.inner)
        )

        for index, checkpoint in enumerate(self.checkpoints):
            checkpoint.draw(
                screen,
                index == next_checkpoint,
                camera,
            )